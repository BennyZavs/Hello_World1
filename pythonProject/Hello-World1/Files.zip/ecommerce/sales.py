def calc_tax():
    pass


def calc_shipping():
    pass
